package com.wischnewsky.minesweeper.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import com.wischnewsky.minesweeper.MainActivity
import com.wischnewsky.minesweeper.R
import com.wischnewsky.minesweeper.model.MinesweeperModel

class MinesweeperView(context: Context?, attrs: AttributeSet?) : View(context, attrs){

    private val paintLine = Paint()
    private val paintBackground = Paint()
    private val paintNumber = Paint()
    private val paintBomb = Paint()
    private val dimension = 5

    init {
        paintBackground.color = Color.GRAY
        paintBackground.style = Paint.Style.FILL

        paintLine.color = Color.BLACK
        paintLine.style = Paint.Style.STROKE
        paintLine.strokeWidth = 2f

        paintNumber.color = Color.RED
        paintNumber.textSize = 50f

        paintBomb.color = Color.BLUE
        paintBomb.textSize = 50f

    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        paintNumber.textSize = (height/dimension).toFloat()
        paintBomb.textSize = (height/dimension).toFloat()
    }

    override fun onDraw(canvas: Canvas?) {
        canvas?.drawRect(0f,0f, width.toFloat(), height.toFloat(), paintBackground)
        drawGameBoard(canvas)
        drawViewableNumbers(canvas)
    }

    private fun drawViewableNumbers(canvas: Canvas?){
        var allFlagged = true

        for(i in 0..dimension-1){
            for(j in 0..dimension-1){
                if(MinesweeperModel.wasClicked(i,j) && MinesweeperModel.isBomb(i,j)) {
                    endLoss()
                }else if(MinesweeperModel.wasFlagged(i,j) && !MinesweeperModel.isBomb(i,j)){
                    endLoss()
                }else if(MinesweeperModel.wasFlagged(i,j)){
                    drawCross(i,j,canvas)
                }else if(MinesweeperModel.wasClicked(i,j)){
                    canvas?.drawText(MinesweeperModel.bombNeighbors(i,j).toString(), ((i)*(width/dimension)).toFloat(), ((j+1)*(height/dimension)).toFloat(), paintNumber )
                }else if(MinesweeperModel.isBomb(i,j) && !MinesweeperModel.wasFlagged(i,j)){
                    allFlagged = false
                }
            }
        }
        if(allFlagged){
            endWin()
        }
    }
    
    private fun endWin(){
        this.resetGame()
        Toast.makeText(context, context.getString(R.string.win_toast), Toast.LENGTH_LONG).show()
    }
    
    private fun endLoss(){
        this.resetGame()
        Toast.makeText(context, context.getString(R.string.loss_toast), Toast.LENGTH_LONG).show()
    }

    private fun drawGameBoard(canvas: Canvas?) {
        // border
        canvas?.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintLine)
        // two horizontal lines
        for(i in 0..dimension-1){
            canvas?.drawLine(0f, (i*(height/dimension)).toFloat(), width.toFloat(), (i*(height/dimension)).toFloat(), paintLine)
            canvas?.drawLine((i*(width/dimension)).toFloat(), 0f, (i*(width/dimension)).toFloat(), height.toFloat(), paintLine)
        }
    }

    fun resetGame(){
        MinesweeperModel.resetGame()
        invalidate()
    }

    fun drawCross(i:Int, j:Int, canvas: Canvas?){
        paintLine.color = Color.GREEN
        canvas?.drawLine((i * width / dimension).toFloat(), (j * height / dimension).toFloat(),
            ((i + 1) * width / dimension).toFloat(),
            ((j + 1) * height / dimension).toFloat(), paintLine)

        canvas?.drawLine(((i + 1) * width / dimension).toFloat(), (j * height / dimension).toFloat(),
            (i * width / dimension).toFloat(), ((j + 1) * height / dimension).toFloat(), paintLine)
        paintLine.color = Color.BLACK
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {

        if(event?.action == MotionEvent.ACTION_DOWN){
            val tX = event.x.toInt()/ (width/dimension)
            val tY = event.y.toInt()/ (height/dimension)


            if (tX < 5 && tY < 5) {
                if((context as MainActivity).flagsOn()){
                    MinesweeperModel.setFlagged(tX,tY)
                }else {
                    MinesweeperModel.setClicked(tX, tY)
                }
                invalidate()
            }
        }

        return true
    }

}