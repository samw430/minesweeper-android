package com.wischnewsky.minesweeper

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.wischnewsky.minesweeper.model.MinesweeperModel
import com.wischnewsky.minesweeper.view.MinesweeperView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resetBtn.setOnClickListener{
            minesweaperView.resetGame()
        }
    }

    fun flagsOn(): Boolean = flagToggle.isChecked



}
