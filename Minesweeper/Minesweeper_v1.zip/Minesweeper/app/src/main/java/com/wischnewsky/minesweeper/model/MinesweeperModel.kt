package com.wischnewsky.minesweeper.model

import android.util.Log

data class SquareInfo(var mine: Boolean, var surrounding_mines: Int, var flagged: Boolean, var clicked: Boolean)

object MinesweeperModel{

    private val dimension = 5
    private val numMines = 3

    private val model = Array<Array<SquareInfo>>(dimension, {_ -> Array<SquareInfo>(dimension, {_ ->  SquareInfo(false, 0, false,false)}) })

    init {
        generateMines()
    }

    private fun generateMines(){
        for (i in 0..numMines) {
            val randomX = (Math.random()*100 % dimension).toInt()
            val randomY = (Math.random()*100 % dimension).toInt()

            if(!model[randomX][randomY].mine) {
                model[randomX][randomY].mine = true
                updateNeighbors(randomX, randomY)
            }
        }
    }

    private fun updateNeighbors(randomX: Int, randomY: Int){
        for (x: Int in -1..1) {
            for (y: Int in -1..1) {
                val neighborX = randomX + x
                val neighborY = randomY + y

                if (neighborX < dimension && neighborX > -1 && neighborY > -1 && neighborY < dimension) {
                    model[neighborX][neighborY].surrounding_mines = model[neighborX][neighborY].surrounding_mines + 1
                }
            }
        }
    }

    fun setClicked(x:Int, y:Int){
        model[x][y].clicked = true
    }

    fun setFlagged(x: Int, y: Int){
        model[x][y].flagged = true
    }

    fun isBomb(x: Int, y: Int) = model[x][y].mine

    fun wasClicked(x:Int, y:Int) = model[x][y].clicked

    fun wasFlagged(x: Int,y: Int) = model[x][y].flagged

    fun bombNeighbors(x:Int, y: Int) = model[x][y].surrounding_mines

    fun resetGame(){
        for(i in 0..dimension-1){
            for(j in 0..dimension-1){
                model[i][j] = SquareInfo(false, 0, false,false)
            }
        }
        generateMines()
    }



}